#include <iostream>
using namespace std;


int up (int a, int b) {return a-b;}
int down(int a, int b) {return b-a;}
